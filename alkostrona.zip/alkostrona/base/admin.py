from django.contrib import admin
from .models import Alcohol, Profile, Like, Review

admin.site.register(Alcohol)
admin.site.register(Profile)
admin.site.register(Like)
admin.site.register(Review)
